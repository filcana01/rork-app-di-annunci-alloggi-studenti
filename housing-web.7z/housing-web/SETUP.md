# USI Inside - App template web

This is the template for the Front End component of a new USI Inside application.

Info and instructions are available on Confluence at the following url:

https://it-usi.atlassian.net/wiki/spaces/UIFE/pages/1094221853
