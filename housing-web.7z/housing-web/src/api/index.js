/* eslint-disable import/prefer-default-export */
import * as Queries from "./queries";
import * as Mutations from "./mutations";

export const Api = {
  Mutations,
  Queries,
};
