import { AppProvider } from "./providers";

function App() {
  return <AppProvider />;
}

export default App;
